﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Parcial1.Migrations
{
    /// <inheritdoc />
    public partial class AddIdentificadores : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Medicamentos_Monodrogas_MonodrogaMedicamentoMonodrogaId",
                table: "Medicamentos");

            migrationBuilder.RenameColumn(
                name: "MonodrogaId",
                table: "Monodrogas",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "MonodrogaMedicamentoMonodrogaId",
                table: "Medicamentos",
                newName: "MonodrogaMedicamentoId");

            migrationBuilder.RenameIndex(
                name: "IX_Medicamentos_MonodrogaMedicamentoMonodrogaId",
                table: "Medicamentos",
                newName: "IX_Medicamentos_MonodrogaMedicamentoId");

            migrationBuilder.RenameColumn(
                name: "DrogueriaId",
                table: "Droguerias",
                newName: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Medicamentos_Monodrogas_MonodrogaMedicamentoId",
                table: "Medicamentos",
                column: "MonodrogaMedicamentoId",
                principalTable: "Monodrogas",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Medicamentos_Monodrogas_MonodrogaMedicamentoId",
                table: "Medicamentos");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Monodrogas",
                newName: "MonodrogaId");

            migrationBuilder.RenameColumn(
                name: "MonodrogaMedicamentoId",
                table: "Medicamentos",
                newName: "MonodrogaMedicamentoMonodrogaId");

            migrationBuilder.RenameIndex(
                name: "IX_Medicamentos_MonodrogaMedicamentoId",
                table: "Medicamentos",
                newName: "IX_Medicamentos_MonodrogaMedicamentoMonodrogaId");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Droguerias",
                newName: "DrogueriaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Medicamentos_Monodrogas_MonodrogaMedicamentoMonodrogaId",
                table: "Medicamentos",
                column: "MonodrogaMedicamentoMonodrogaId",
                principalTable: "Monodrogas",
                principalColumn: "MonodrogaId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
