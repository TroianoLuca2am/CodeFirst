﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Parcial1.Migrations
{
    /// <inheritdoc />
    public partial class ReconstruyendoClasesII : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ID_MONODROGRA",
                table: "Medicamentos",
                newName: "MonodrogaId");

            migrationBuilder.CreateTable(
                name: "DrogueriaMedicamento",
                columns: table => new
                {
                    DrogueriasId = table.Column<int>(type: "int", nullable: false),
                    MedicamentosId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DrogueriaMedicamento", x => new { x.DrogueriasId, x.MedicamentosId });
                    table.ForeignKey(
                        name: "FK_DrogueriaMedicamento_Droguerias_DrogueriasId",
                        column: x => x.DrogueriasId,
                        principalTable: "Droguerias",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DrogueriaMedicamento_Medicamentos_MedicamentosId",
                        column: x => x.MedicamentosId,
                        principalTable: "Medicamentos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Medicamentos_MonodrogaId",
                table: "Medicamentos",
                column: "MonodrogaId");

            migrationBuilder.CreateIndex(
                name: "IX_DrogueriaMedicamento_MedicamentosId",
                table: "DrogueriaMedicamento",
                column: "MedicamentosId");

            migrationBuilder.AddForeignKey(
                name: "FK_Medicamentos_Monodrogas_MonodrogaId",
                table: "Medicamentos",
                column: "MonodrogaId",
                principalTable: "Monodrogas",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Medicamentos_Monodrogas_MonodrogaId",
                table: "Medicamentos");

            migrationBuilder.DropTable(
                name: "DrogueriaMedicamento");

            migrationBuilder.DropIndex(
                name: "IX_Medicamentos_MonodrogaId",
                table: "Medicamentos");

            migrationBuilder.RenameColumn(
                name: "MonodrogaId",
                table: "Medicamentos",
                newName: "ID_MONODROGRA");
        }
    }
}
