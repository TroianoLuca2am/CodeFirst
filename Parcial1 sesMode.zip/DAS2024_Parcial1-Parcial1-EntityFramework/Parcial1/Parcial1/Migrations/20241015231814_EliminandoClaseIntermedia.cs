﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Parcial1.Migrations
{
    /// <inheritdoc />
    public partial class EliminandoClaseIntermedia : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Medicamentos_Droguerias");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Medicamentos_Droguerias",
                columns: table => new
                {
                    Id_Medicamento = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DrogueriaId = table.Column<int>(type: "int", nullable: false),
                    MedicamentoId = table.Column<int>(type: "int", nullable: false),
                    Id_Drogueria = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Medicamentos_Droguerias", x => x.Id_Medicamento);
                    table.ForeignKey(
                        name: "FK_Medicamentos_Droguerias_Droguerias_DrogueriaId",
                        column: x => x.DrogueriaId,
                        principalTable: "Droguerias",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Medicamentos_Droguerias_Medicamentos_MedicamentoId",
                        column: x => x.MedicamentoId,
                        principalTable: "Medicamentos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Medicamentos_Droguerias_DrogueriaId",
                table: "Medicamentos_Droguerias",
                column: "DrogueriaId");

            migrationBuilder.CreateIndex(
                name: "IX_Medicamentos_Droguerias_MedicamentoId",
                table: "Medicamentos_Droguerias",
                column: "MedicamentoId");
        }
    }
}
