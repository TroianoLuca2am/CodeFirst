﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Parcial1.Migrations
{
    /// <inheritdoc />
    public partial class ArmandoRelacionUnoAMuchos : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Medicamentos_Monodrogas_MonodrogaMedicamentoId",
                table: "Medicamentos");

            migrationBuilder.DropIndex(
                name: "IX_Medicamentos_MonodrogaMedicamentoId",
                table: "Medicamentos");

            migrationBuilder.RenameColumn(
                name: "VentaLibre",
                table: "Medicamentos",
                newName: "Es_Venta_Libre");

            migrationBuilder.RenameColumn(
                name: "StockMinimo",
                table: "Medicamentos",
                newName: "Stock_Minimo");

            migrationBuilder.RenameColumn(
                name: "StockActual",
                table: "Medicamentos",
                newName: "Stock");

            migrationBuilder.RenameColumn(
                name: "PrecioVenta",
                table: "Medicamentos",
                newName: "Precio_Venta");

            migrationBuilder.RenameColumn(
                name: "NombreComercial",
                table: "Medicamentos",
                newName: "Nombre_Comercial");

            migrationBuilder.RenameColumn(
                name: "MonodrogaMedicamentoId",
                table: "Medicamentos",
                newName: "ID_MONODROGRA");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "Droguerias",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "MedicamentoId",
                table: "Droguerias",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MedicamentoId",
                table: "Droguerias");

            migrationBuilder.RenameColumn(
                name: "Stock_Minimo",
                table: "Medicamentos",
                newName: "StockMinimo");

            migrationBuilder.RenameColumn(
                name: "Stock",
                table: "Medicamentos",
                newName: "StockActual");

            migrationBuilder.RenameColumn(
                name: "Precio_Venta",
                table: "Medicamentos",
                newName: "PrecioVenta");

            migrationBuilder.RenameColumn(
                name: "Nombre_Comercial",
                table: "Medicamentos",
                newName: "NombreComercial");

            migrationBuilder.RenameColumn(
                name: "ID_MONODROGRA",
                table: "Medicamentos",
                newName: "MonodrogaMedicamentoId");

            migrationBuilder.RenameColumn(
                name: "Es_Venta_Libre",
                table: "Medicamentos",
                newName: "VentaLibre");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "Droguerias",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Medicamentos_MonodrogaMedicamentoId",
                table: "Medicamentos",
                column: "MonodrogaMedicamentoId");

            migrationBuilder.AddForeignKey(
                name: "FK_Medicamentos_Monodrogas_MonodrogaMedicamentoId",
                table: "Medicamentos",
                column: "MonodrogaMedicamentoId",
                principalTable: "Monodrogas",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
