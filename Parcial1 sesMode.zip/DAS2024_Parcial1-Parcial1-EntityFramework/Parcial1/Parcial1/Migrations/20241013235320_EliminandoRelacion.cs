﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Parcial1.Migrations
{
    /// <inheritdoc />
    public partial class EliminandoRelacion : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MedicamentoId",
                table: "Droguerias");

            migrationBuilder.RenameColumn(
                name: "MedicamentoId",
                table: "Medicamentos",
                newName: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Medicamentos",
                newName: "MedicamentoId");

            migrationBuilder.AddColumn<int>(
                name: "MedicamentoId",
                table: "Droguerias",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
