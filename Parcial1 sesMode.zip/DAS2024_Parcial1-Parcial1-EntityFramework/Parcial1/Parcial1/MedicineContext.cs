﻿using Microsoft.EntityFrameworkCore;
using Modelo.Objetos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.RepositoriosEntityFramework
{
    public class MedicineContext : DbContext
    {
        public DbSet<Drogueria> Droguerias { get; set; }
        public DbSet<Medicamento> Medicamentos { get; set; }
        public DbSet<Monodroga> Monodrogas { get; set; }

        public string DbPath { get; }
        public MedicineContext()
        {
            var folder = Environment.SpecialFolder.LocalApplicationData;
            var path = Environment.GetFolderPath(folder);
            DbPath = Path.Join(path, "medicine.db");
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options) => options.UseSqlServer($"Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PARCIAL1;Integrated Security=true;");
    }
}
