using Controladora;
using Modelo.Objetos;

namespace Parcial1
{
    public partial class Form1 : Form
    {
        private List<Drogueria> droguerias;
        Drogueria drogueriaSeleccionada;
        ControladoraMedicamentos controMedi = new ControladoraMedicamentos();
        public Form1()
        {
            InitializeComponent();
            ActualizarCMBS();
            droguerias = new List<Drogueria>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ActualizarCMBS();
        }

        private void ActualizarCMBS()
        {
            cmbDroguerias.DataSource = null;
            cmbDroguerias.DataSource = controMedi.LeerDrogueria();
            cmbMonodrogas.DataSource = null;
            cmbMonodrogas.DataSource = controMedi.LeerMonodroga();
        }

        private void btnCargarDrogueria_Click(object sender, EventArgs e)
        {
            var drogueria = controMedi.BuscarDrogueria(long.Parse(cmbDroguerias.Text));
            if (drogueria != null)
            {
                var filtrarEnLista = droguerias.FirstOrDefault(dr => dr.Id == drogueria.Id);
                if (filtrarEnLista == null)
                {
                    droguerias.Add(drogueria);
                    ActualizarGrilla();
                    lblLeyenda.Text = "";
                }
                else
                {
                    lblLeyenda.Text = "Esta drogueria ya se encuentra registrada.";
                }
                lblLeyenda.Visible = true;
            }
        }

        private void ActualizarGrilla()
        {
            dgvDrogueriasDelMedicamento.DataSource = null;
            dgvDrogueriasDelMedicamento.DataSource = droguerias.AsReadOnly();
        }

        private void btnRegistrarMedicamento_Click(object sender, EventArgs e)
        {
            var medicamento = ValidarCrearRegistroMedicamento();
            if (medicamento != null)
            {
                foreach(Drogueria dro in droguerias)
                {
                    medicamento.AgregarDrogueria(dro);
                }
                medicamento.Monodroga = controMedi.BuscarMonodroga(cmbMonodrogas.Text);
                if (controMedi.CargarMedicamento(medicamento))
                {
                    lblLeyenda.Text = "Medicamento cargado con �xito.";
                }
                else
                {
                    lblLeyenda.Text = "El medicamento no pudo ser registrado.";
                }
            }
            else
            {
                lblLeyenda.Text = "Completar todos los campos";
            }
            lblLeyenda.Visible = true;
            droguerias.Clear();
            ActualizarGrilla();
        }

        private Medicamento ValidarCrearRegistroMedicamento()
        {
            if (txtNombreComercial.Text != "" && txtPrecioVenta.Text != "" && txtStockActual.Text != "" && txtStockMinimo.Text != "" && cmbDroguerias.Text != "" && cmbMonodrogas.Text != "")
            {
                Medicamento medicamento = new Medicamento()
                {
                    Nombre_Comercial = txtNombreComercial.Text,
                    Precio_Venta = decimal.Parse(txtPrecioVenta.Text),
                    Stock = int.Parse(txtStockActual.Text),
                    Stock_Minimo = int.Parse(txtStockMinimo.Text),
                    Es_Venta_Libre = rbVentaLibre.Checked
                };
                return medicamento;
            }
            else
            {
                return null;
            }
        }

        private void btnVerMedicamentos_Click(object sender, EventArgs e)
        {
            FormMedicamentos formMedicamentos = new FormMedicamentos();
            formMedicamentos.ShowDialog();
        }

        private void dgvDrogueriasDelMedicamento_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            drogueriaSeleccionada = controMedi.LeerDrogueria().FirstOrDefault(dr => dr.Id == int.Parse(dgvDrogueriasDelMedicamento.Rows[e.RowIndex].Cells[0].Value.ToString()));
        }

        private void btnEliminarDrogueria_Click(object sender, EventArgs e)
        {
            if (drogueriaSeleccionada!=null)
            {
                droguerias.Remove(drogueriaSeleccionada);
                ActualizarGrilla();
            }
        }
    }
}