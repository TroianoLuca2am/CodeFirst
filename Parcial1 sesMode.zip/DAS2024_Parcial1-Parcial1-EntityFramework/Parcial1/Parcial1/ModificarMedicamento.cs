﻿using Controladora;
using Modelo.Objetos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parcial1
{
    public partial class ModificarMedicamento : Form
    {
        Medicamento medicamento;
        List<Drogueria> drogueriaList;
        Drogueria drogueriaSeleccionada = new Drogueria();
        ControladoraMedicamentos controMedi = new ControladoraMedicamentos();
        public ModificarMedicamento(Medicamento medi)
        {
            InitializeComponent();
            drogueriaList = [];
            medicamento = medi;
        }

        private void ModificarMedicamento_Load(object sender, EventArgs e)
        {
           /* foreach (Drogueria drog in controMedi.LeerDrogueriasDeMedicamento(medicamento))
            {
                drogueriaList.Add(drog);
            }*/

            ActualizarGrilla();

            cmbDroguerias.DataSource = null;
            cmbDroguerias.DataSource = controMedi.LeerDrogueria();

            txtNombreComercial.Text = medicamento.Nombre_Comercial;
            txtNombreComercial.Enabled = false;

            txtPrecioVenta.Text = medicamento.Precio_Venta.ToString();
            txtStockActual.Text = medicamento.Stock.ToString();
            txtStockMinimo.Text = medicamento.Stock_Minimo.ToString();

            cmbMonodrogas.DataSource = null;
            cmbMonodrogas.DataSource = controMedi.LeerMonodroga();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (txtNombreComercial.Text != "" && txtPrecioVenta.Text != "" && txtStockActual.Text != "" && txtStockMinimo.Text != "" && cmbMonodrogas.Text != "")
            {
                Medicamento medicamentoActualizado = new Medicamento()
                {
                    Id = medicamento.Id,
                    Nombre_Comercial = txtNombreComercial.Text,
                    Precio_Venta = decimal.Parse(txtPrecioVenta.Text),
                    Stock = int.Parse(txtStockActual.Text),
                    Stock_Minimo = int.Parse(txtStockMinimo.Text),
                    Monodroga = controMedi.LeerMonodroga().FirstOrDefault(mo => mo.Nombre == cmbMonodrogas.Text)
                };

                foreach (Drogueria drogueria in drogueriaList)
                {
                    medicamentoActualizado.AgregarDrogueria(drogueria);
                }

               if (controMedi.ActualizarMedicamento(medicamentoActualizado))
                {
                    lblLeyenda.Text = "Modificado con éxito.";
                }
                else
                {
                    lblLeyenda.Text = "Error en la base de datos.";
                }
            }
            else
            {
                lblLeyenda.Text = "Completar todos los campos";
            }
            lblLeyenda.Visible = true;
        }

        private void ActualizarGrilla()
        {
            dgvDrogueriasDelMedicamento.DataSource = null;
            dgvDrogueriasDelMedicamento.DataSource = drogueriaList.AsReadOnly();
        }

        private void dgvDrogueriasDelMedicamento_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            drogueriaSeleccionada = controMedi.LeerDrogueria().FirstOrDefault(dr => dr.Id == int.Parse(dgvDrogueriasDelMedicamento.Rows[e.RowIndex].Cells[0].Value.ToString()));
        }

        private void btnEliminarDrogueria_Click(object sender, EventArgs e)
        {
            if (drogueriaSeleccionada != null)
            {
                drogueriaList.Remove(drogueriaSeleccionada);
                ActualizarGrilla();
            }
            else
            {
                lblLeyenda.Text = "Debe seleccionar alguna drogueria";
                lblLeyenda.Visible = true;
            }
        }

        private void btnCargarDrogueria_Click(object sender, EventArgs e)
        {
            var drogueria = controMedi.LeerDrogueria().FirstOrDefault(dr=>dr.Cuit==long.Parse(cmbDroguerias.Text));
            if (drogueria!=null)
            {
                drogueriaList.Add(drogueria);
                ActualizarGrilla();
            }
            else
            {
                lblLeyenda.Text = "No se pudo agregar drogueria.";
                lblLeyenda.Visible = true;
            }
        }
    }
}
