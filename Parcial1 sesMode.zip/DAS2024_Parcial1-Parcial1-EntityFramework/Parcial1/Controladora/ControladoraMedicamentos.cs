﻿using Modelo.Objetos;
//using Modelo.Repositorios;
using Modelo.RepositoriosEntityFramework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controladora
{
    public class ControladoraMedicamentos
    {
        RepositorioMedicamentos repoMedi = new RepositorioMedicamentos();
        RepositorioMonodrogas repoMono = new RepositorioMonodrogas();
        RepositorioDroguerias repoDrog = new RepositorioDroguerias();

        public ReadOnlyCollection<Medicamento> LeerMedicamento()
        {
            return repoMedi.Read();
        }
        public ReadOnlyCollection<Monodroga> LeerMonodroga()
        {
            return repoMono.Read();
        }
        public ReadOnlyCollection<Drogueria> LeerDrogueria()
        {
            return repoDrog.Read();
        }
        /*public ReadOnlyCollection<Drogueria> LeerDrogueriasDeMedicamento(Medicamento medicamento)
        {
            return repoDrog.ReadDrogueriasDeMedicamento(medicamento);
        }*/

        public Drogueria BuscarDrogueria(long cuit)
        {
            return LeerDrogueria().FirstOrDefault(dr => dr.Cuit == cuit);
        }
        public Monodroga BuscarMonodroga(string nombre)
        {
            return LeerMonodroga().FirstOrDefault(mo => mo.Nombre == nombre);
        }

        public bool CargarMedicamento(Medicamento medicamento)
        {
            var busqueda = repoMedi.Read().FirstOrDefault(m=>m.Id == medicamento.Id);
            if (busqueda==null)
            {
                repoMedi.Create(medicamento);
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool ActualizarMedicamento(Medicamento medicamentoActualizado)
        {
            var busqueda = repoMedi.Read().FirstOrDefault(m=>m.Id == medicamentoActualizado.Id);
            if (busqueda!=null)
            {
                repoMedi.Update(medicamentoActualizado);
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool EliminarMedicamento(string nombre)
        {
            var busqueda = repoMedi.Read().FirstOrDefault(m=>m.Nombre_Comercial==nombre);
            if (busqueda!=null)
            {
                repoMedi.Delete(busqueda);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
