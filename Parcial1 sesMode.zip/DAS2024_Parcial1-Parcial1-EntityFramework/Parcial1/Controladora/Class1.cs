﻿namespace Controladora
{
    public class Class1
    {

    }
}