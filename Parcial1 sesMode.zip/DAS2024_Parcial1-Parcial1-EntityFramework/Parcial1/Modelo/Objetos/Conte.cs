﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Objetos
{
    public class Conte:DbContext
    {
        protected override void OnModelCreating(ModelBuilder model)
        {
            model.Entity<Monodroga>().ToTable("");
            model.Entity<Monodroga>().HasKey(x => );
        }
    }
}
