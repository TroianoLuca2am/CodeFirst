﻿using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;

namespace Modelo.Objetos
{
    public class Drogueria
    {
        [Key]
        public int Id { get; set; }
        public long Cuit { get; set; }
        public string Razon_Social { get; set; }
        public string Direccion { get; set; }
        public string? Email { get; set; }
        
        //public List<Medicamentos_Droguerias> Medicamentos_Droguerias { get; set; }

        public List<Medicamento> Medicamentos { get; set; } = new List<Medicamento>();

        public override string ToString()
        {
            return Cuit.ToString();
        }
    }
}
