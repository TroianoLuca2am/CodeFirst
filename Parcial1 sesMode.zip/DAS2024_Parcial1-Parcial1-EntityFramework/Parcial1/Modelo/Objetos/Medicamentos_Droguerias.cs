﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Objetos
{
    public class Medicamentos_Droguerias
    {
        [Key]
        public int Id_Medicamento { get; set; }
        public Medicamento Medicamento { get; set; }
        [Key]
        public int Id_Drogueria { get; set; }
        public Drogueria Drogueria { get; set; }
    }
}
