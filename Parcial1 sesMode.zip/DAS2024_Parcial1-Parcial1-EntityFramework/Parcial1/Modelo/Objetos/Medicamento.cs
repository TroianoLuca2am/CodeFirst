﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Objetos
{
    public class Medicamento
    {
        //nombre comercial, si es de venta libre, el precio de venta, el stock actual y el stock mínimo.
        [Key]
        public int Id { get; set; }
        public string Nombre_Comercial { get; set; }
        public bool Es_Venta_Libre { get; set; }
        [Precision (18,2)]
        public decimal Precio_Venta { get; set; }
        public int Stock { get; set; }
        public int Stock_Minimo { get; set; }

        public Monodroga Monodroga { get; set; }

        public int MonodrogaId { get; set; }
  
        public List<Drogueria> Droguerias { get; set; } = new List<Drogueria>();



        public void AgregarDrogueria(Drogueria drogueria)
        {
            var droFiltrada = Droguerias.FirstOrDefault(drog=>drog.Id==drogueria.Id);
            if (droFiltrada==null)
            {
                Droguerias.Add(drogueria);
            }
        }
        public override string ToString()
        {
            return Nombre_Comercial;
        }
    }
}
