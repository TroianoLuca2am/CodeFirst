﻿using Modelo.Objetos;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.RepositoriosEntityFramework
{
    public class RepositorioDroguerias
    {
        public ReadOnlyCollection<Drogueria> Read()
        {
            using var db = new MedicineContext();
            return db.Droguerias.OrderBy(o => o.Id).ToList().AsReadOnly();
        }
        /*public ReadOnlyCollection<Drogueria> ReadDrogueriasDeMedicamento(Medicamento medicamento)
        {
            List<Drogueria> droguerias = new List<Drogueria>();
            using var db = new MedicineContext();
            using var db2 = new MedicineContext();
            foreach (Medicamentos_Droguerias me_dr in db.Medicamentos_Droguerias)
            {
                if (me_dr.Id_Medicamento==medicamento.Id)
                {
                    droguerias.Add(db2.Droguerias.FirstOrDefault(dr => dr.Id == me_dr.Id_Drogueria));
                }
            }
            db.SaveChanges();
            return droguerias.AsReadOnly();
        }*/
    }
}
