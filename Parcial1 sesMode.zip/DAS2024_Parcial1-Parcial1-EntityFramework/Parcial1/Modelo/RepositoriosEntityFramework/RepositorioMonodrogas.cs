﻿using Modelo.Objetos;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.RepositoriosEntityFramework
{
    public class RepositorioMonodrogas
    {
        public ReadOnlyCollection<Monodroga> Read()
        {
            using var db = new MedicineContext();
            return db.Monodrogas.ToList().AsReadOnly();
        }
    }
}
