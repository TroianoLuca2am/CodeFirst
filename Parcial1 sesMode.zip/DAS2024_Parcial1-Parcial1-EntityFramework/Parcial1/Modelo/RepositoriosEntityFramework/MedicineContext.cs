﻿using Microsoft.EntityFrameworkCore;
using Modelo.Objetos;

namespace Modelo.RepositoriosEntityFramework
{
    public class MedicineContext : DbContext
    {
        public DbSet<Drogueria> Droguerias { get; set; }
        public DbSet<Medicamento> Medicamentos { get; set; }
        public DbSet<Monodroga> Monodrogas { get; set; }
        //public DbSet<Medicamentos_Droguerias> Medicamentos_Droguerias { get; set; }
        public MedicineContext()
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            Model.Entity<Monodroga>
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options) => options.UseSqlServer($"Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PARCIAL1;Integrated Security=true;");

        /*protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuración de la clave compuesta
            modelBuilder.Entity<Medicamentos_Droguerias>()
                .HasKey(md => new { md.Id_Medicamento, md.Id_Drogueria });

            // Configuración de relaciones muchos-a-muchos
            modelBuilder.Entity<Medicamentos_Droguerias>()
                .HasOne(md => md.Medicamento)
                .WithMany(m => m.Medicamentos_Droguerias)
                .HasForeignKey(md => md.Id_Medicamento);

            modelBuilder.Entity<Medicamentos_Droguerias>()
                .HasOne(md => md.Drogueria)
                .WithMany(d => d.Medicamentos_Droguerias)
                .HasForeignKey(md => md.Id_Drogueria);
        }*/

    }
}
