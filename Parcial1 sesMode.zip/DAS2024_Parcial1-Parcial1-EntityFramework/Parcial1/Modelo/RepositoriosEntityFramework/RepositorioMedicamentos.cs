﻿using Modelo.Objetos;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.RepositoriosEntityFramework
{
    public class RepositorioMedicamentos
    {
        public void Create(Medicamento medicamento)
        {
            using var db = new MedicineContext();
            db.Add(medicamento);
            db.SaveChanges();          
        }
        public ReadOnlyCollection<Medicamento> Read()
        {
            using var db = new MedicineContext();
            return db.Medicamentos.OrderBy(o=>o.Id).ToList().AsReadOnly();
        }
        public void Delete(Medicamento medicamento)
        {
            using var db2 = new MedicineContext();
            db2.Remove(medicamento);
            db2.SaveChanges();
        }
        public void Update(Medicamento medicamento)
        {
            using var db = new MedicineContext();
            var busqueda = db.Medicamentos.FirstOrDefault(m=>m.Id == medicamento.Id);
            db.Remove(busqueda);
            db.Add(medicamento);
            db.SaveChanges();
        }
    }
}
